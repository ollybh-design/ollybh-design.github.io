/* Portfolio: one shared WebGL renderer draws every model view on the page (three.js r160). */
import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { MeshoptDecoder } from "three/addons/libs/meshopt_decoder.module.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";

const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
const clamp = THREE.MathUtils.clamp, lerp = THREE.MathUtils.lerp;
const smooth = k => { k = clamp(k, 0, 1); return k * k * (3 - 2 * k); };

/* ------------------------------------------------------------ renderer */
const canvas = document.getElementById("gl");
const COPY = false;   // per-view copy tested on phones: too slow (GPU readback every frame), so off
if (COPY) canvas.style.visibility = "hidden";
let renderer;
let noGL = false;
try { renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: "high-performance" }); }
catch (e) {
  // no WebGL: keep every other control working; 3D areas fall back to stills (see .nogl CSS)
  noGL = true; canvas.remove(); document.documentElement.classList.add("nogl"); console.warn("WebGL unavailable", e);
  const noop = new Proxy(function () {}, { get: (t, k) => k === Symbol.toPrimitive ? () => 0 : noop, apply: () => noop, set: () => true });
  renderer = noop;
}
renderer.setPixelRatio(Math.min(devicePixelRatio, innerWidth < 760 ? 1.25 : 1.5));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
renderer.setClearColor(0x000000, 0);
renderer.setScissorTest(true);
const envTex = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(), 0.04).texture;

const SHADOW = (() => {
  const c = document.createElement("canvas"); c.width = c.height = 128;
  const g = c.getContext("2d"), r = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  r.addColorStop(0, "rgba(0,0,0,0.30)"); r.addColorStop(0.55, "rgba(0,0,0,0.10)"); r.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = r; g.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
})();

/* ------------------------------------------------------------ models */
const loader = new GLTFLoader(); loader.setMeshoptDecoder(MeshoptDecoder);
const cache = {};
// models: retry a failed download a few times before giving up
const loadOnce = key => new Promise((res, rej) => loader.load("model/" + key + "-glb.wasm", g => res(g.scene), undefined, rej));
const getModel = key => cache[key] || (cache[key] = (async () => {
  for (let i = 0; ; i++) {
    try { return await loadOnce(key); }
    catch (e) { if (i >= 5) { delete cache[key]; throw e; } await new Promise(r => setTimeout(r, 800 * (i + 1))); }
  }
})());

// images: if one fails, ask for it again (up to 5 times, backing off)
addEventListener("error", e => {
  const im = e.target;
  if (!(im instanceof HTMLImageElement) || !im.getAttribute("src") || im.src.startsWith("data:")) return;
  const n = +(im.dataset.retry || 0); if (n >= 5) return;
  im.dataset.retry = n + 1;
  const src = im.getAttribute("src");
  setTimeout(() => { im.removeAttribute("src"); im.setAttribute("src", src); }, 700 * (n + 1));
}, true);
// any image that already failed before this script ran
document.querySelectorAll("img").forEach(im => { if (im.complete && im.naturalWidth === 0 && im.getAttribute("src") && !im.src.startsWith("data:")) im.dispatchEvent(new Event("error")); });

/* Put a model in a group centred on the origin and record every part (home position, centre, name). */
function partName(o) {
  for (let n = o; n; n = n.parent) if (n.name && /__(\d+|p\d+|b\d+|barrel|handle|pin|lid|lidline|rail|frame|seam)$|^bristles$/.test(n.name)) return n.name;
  return o.name || "";
}
function prepare(src, ghost) {
  const root = src.clone(true);
  realMaterials(root);
  root.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(root), C = box.getCenter(new THREE.Vector3()), S = box.getSize(new THREE.Vector3());
  const parts = [];
  root.traverse(o => {
    if (!o.isMesh) return;
    if (ghost) o.material = o.material.clone();
    const bx = new THREE.Box3().setFromObject(o), cRaw = bx.getCenter(new THREE.Vector3());
    parts.push({ o, name: partName(o), mat: o.material.name, home: o.position.clone(), raw: cRaw, box: bx, c: cRaw.clone().sub(C) });
  });
  root.position.sub(C);
  const g = new THREE.Group(); g.add(root);
  return { group: g, root, C, parts, size: S, radius: S.length() / 2 };
}

/* Offsets that each part travels when fully exploded. */
function explodeVectors(key, m) {
  const R = m.radius;
  m.parts.forEach(p => {
    const d = p.c, v = new THREE.Vector3();
    if (key === "henry") {
      const brush = p.name === "bristles" || (p.mat === "black" && d.y < -m.size.y * 0.15);
      const tissue = p.mat === "eyewhite" && d.y > m.size.y * 0.1;
      v.set(d.x * 1.6 + Math.sign(d.x) * R * 0.18, d.y * 1.2 + (brush ? -R * 0.5 : 0) + (tissue ? R * 0.45 : 0), d.z * 1.2);
    } else {
      const n = d.clone(); if (n.lengthSq() < 1e-6) n.set(0, 1, 0);
      v.copy(d).multiplyScalar(0.85).addScaledVector(n.normalize(), R * 0.1);
      if (key === "speaker") v.z += d.z * 1.4;
      if (key === "scooter") { v.set(d.x * 0.45, d.y * 0.22 + (d.y > 0 ? R * 0.06 : 0), d.z * 2.2 + Math.sign(d.z) * R * 0.08); }
    }
    p.ex = v;
  });
  if (key === "henry") {
    const big = m.parts.filter(p => p.mat === "pink" && p.box && Math.min(...p.box.getSize(new THREE.Vector3()).toArray()) > 12);
    m.parts.forEach(p => {
      const sz = p.box.getSize(new THREE.Vector3()), small = Math.max(sz.x, sz.y, sz.z) < 8.5;
      if (!small || p.name === "bristles" || !big.length) return;
      let best = big[0], bd = 1e9;
      big.forEach(q => { const z = q.box.getSize(new THREE.Vector3()), d = q.box.distanceToPoint(p.raw) + z.x * z.y * z.z * 1e-6; if (d < bd) { bd = d; best = q; } });
      p.ex = best.ex.clone();
    });
  }
}
function stickLogo(m) {
  const host = re => m.parts.find(p => re.test(p.name));
  const logo = host(/^LOGO-IKEA__\d+$/), shell = host(/^Layer[ _]01__\d+$/);
  if (logo && shell) logo.ex = shell.ex.clone();
  const plg = host(/^PLUG-USB__/), teth = host(/^PLUG-TETHER__/);
  if (plg && teth) teth.ex = plg.ex.clone();
  // wiring stays tucked against the motor core instead of flying out on its own
  const core = host(/^motor__\d+$/);
  if (core) m.parts.forEach(p => { if (/^INT-(wires|sleeve)__/.test(p.name)) p.ex = core.ex.clone(); if (/^INT-sleeve__/.test(p.name)) p.sleeve = true; });
  // cover patches travel with the shell they belong to
  m.parts.forEach(p => {
    const k = p.name.match(/^(Front[ _]Left|Layer[ _]01|LOGO-IKEA|Bottom[ _]Left|Bottom[ _]Right)__p\d+$/);
    if (!k) return; const h = host(new RegExp("^" + k[1] + "__\\d+$")); if (h) p.ex = h.ex.clone();
  });
  // screws sit under flush plugs in their holes; exploded, plug then screw back straight out of the hole
  const C = m.C || new THREE.Vector3();
  m.parts.forEach(p => {
    const k = p.name.match(/^(PLUG|INT-screws)__(barrel|handle)$/); if (!k) return;
    const w = p.c.clone().add(C), barrel = k[2] === "barrel";
    const dir = barrel ? new THREE.Vector3(w.x, w.y - 99.46, 0) : new THREE.Vector3(w.x, 0, w.z);
    dir.normalize();
    const h = host(barrel ? /^Layer[ _]01__\d+$/ : /^Bottom[ _]Right__\d+$/);
    p.ex = (h ? h.ex.clone() : new THREE.Vector3()).addScaledVector(dir, k[1] === "PLUG" ? 46 : 30);
  });
}
function applyExplode(m, t) { m.parts.forEach(p => { p.o.position.copy(p.home).addScaledVector(p.ex, t); if (p.sleeve) p.o.visible = t < 0.03; }); }   // wire sleeves come off once it opens, showing the red and white wires

/* Route 42 teardown in three cumulative moves: tray out, base open, every part. */
function r42Vectors(m) {
  const splitX = 83; // the base splits at X 83 in the CAD
  const box = new THREE.Box3(); m.parts.forEach(p => box.expandByPoint(p.raw));
  m.parts.forEach(p => {
    const n = p.name, left = p.raw.x < splitX, lower = /Lower/.test(n), d = p.c;
    const s1 = new THREE.Vector3(), s2 = new THREE.Vector3(), s3 = new THREE.Vector3();
    if (/Bench_Tray/.test(n)) s1.set(0, -4, 46);
    if (!lower && !/Controller/.test(n)) s2.y += 40; // the CAD's own exploded spacing: decks lift 40
    s2.x += left ? -20 : 20;                            // and the halves part 40 at X 83
    s3.set(d.x * 0.55, d.y * 0.55 + 10, d.z * 1.3);
    if (/Upper/.test(n)) s3.y += 22;
    if (/Lamp_Shell_Front/.test(n)) s3.z += 26;
    if (/Lamp_Shell_Back/.test(n)) s3.z -= 26;
    if (/Diffuser|Light_Strip/.test(n)) s3.y += 16;
    if (/Sign_Disc|Sign_Panel/.test(n)) s3.z += 20;
    if (/Bench_Seat/.test(n)) s3.y += 18;
    if (/Bench_Tray/.test(n)) s3.z += 20;
    p.st = [s1, s2, s3];
  });
}
function applyR42(m, e) {
  // e is either a number (cumulative stages) or an array of weights, one per stage
  m.parts.forEach(p => {
    p.o.position.copy(p.home);
    p.st.forEach((s, i) => p.o.position.addScaledVector(s, Array.isArray(e) ? smooth(e[i] || 0) : smooth(e - i)));
  });
}
function centreOf(m, re) {
  const b = new THREE.Box3();
  m.parts.forEach(p => { if (!p.prop && re.test(p.name)) b.expandByPoint(p.c); });
  return b.isEmpty() ? new THREE.Vector3() : b.getCenter(new THREE.Vector3());
}

/* Desk props for Route 42: pencils, pens, a rubber and a sticky note, carried by the part they sit in. */
function setOpacity(mat, op) {
  mat.opacity = op; const tr = op < 0.99 || !!mat.userData.keepAlpha;   // printed logos keep their see-through edges
  if (mat.transparent !== tr) { mat.transparent = tr; mat.depthWrite = !tr; mat.needsUpdate = true; }
}
function fadePart(p, op) {
  p.o.visible = op > 0.01;
  if (p.mats) p.mats.forEach(mt => setOpacity(mt, op)); else setOpacity(p.o.material, op);
}
function addR42Props(m) {
  const find = re => m.parts.find(p => re.test(p.name));
  const bin = find(/Pen_Holder/), seat = find(/Bench_Seat/), panel = find(/Back_Panel/);
  if (!bin || !seat || !panel) return;
  const M = (c, r = 0.6) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: 0 });
  const props = [];
  const put = (obj, host, name) => {
    m.root.add(obj);
    const mats = []; obj.traverse(o => { if (o.isMesh) mats.push(o.material); });
    props.push({ o: obj, mats, name, home: obj.position.clone(), st: host.st, ex: host.ex, prop: true });
  };
  const b = bin.box, cx = (b.min.x + b.max.x) / 2, cz = (b.min.z + b.max.z) / 2, floor = b.min.y + 4;
  // each stick stands on the floor of the bore and leans against the rim, so nothing passes through the wall
  const top = b.max.y, UP = new THREE.Vector3(0, 1, 0);
  const stick = (bx, bz, rx, rz) => {
    const g = new THREE.Group(), B = new THREE.Vector3(cx + bx, floor, cz + bz), R = new THREE.Vector3(cx + rx, top, cz + rz);
    g.position.copy(B); g.quaternion.setFromUnitVectors(UP, R.sub(B).normalize()); return g;
  };
  const pencil = (col, len, bx, bz, rx, rz) => {
    const g = stick(bx, bz, rx, rz);
    const body = new THREE.Mesh(new THREE.CylinderGeometry(3.6, 3.6, len - 18, 6), M(col, 0.5)); body.position.y = (len - 18) / 2;
    const wood = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 3.6, 15, 6), M(0xE6C49A, 0.8)); wood.position.y = len - 18 + 7.5;
    const lead = new THREE.Mesh(new THREE.ConeGeometry(1.1, 3, 6), M(0x2A2A2A, 0.4)); lead.position.y = len - 1.5;
    g.add(body, wood, lead); put(g, bin, "Pen_Holder_prop");
  };
  const pen = (col, len, bx, bz, rx, rz) => {
    const g = stick(bx, bz, rx, rz);
    const body = new THREE.Mesh(new THREE.CylinderGeometry(4.2, 4.2, len, 16), M(col, 0.35)); body.position.y = len / 2;
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(4.5, 4.5, 34, 16), M(col, 0.3)); cap.position.y = len - 17;
    const clip = new THREE.Mesh(new THREE.BoxGeometry(1.4, 26, 1.6), M(0xB9BCC2, 0.25)); clip.position.set(0, len - 18, 5.1);
    g.add(body, cap, clip); put(g, bin, "Pen_Holder_prop");
  };
  // a 2.5 mm divider splits the bore left and right: pens on the left, pencils on the right
  const div = new THREE.Mesh(new THREE.BoxGeometry(2.5, top - floor - 1, 38.4), M(0xC9C7C2, 0.7));
  div.position.set(cx, floor + (top - floor - 1) / 2, cz); put(div, bin, "Pen_Holder_prop");
  pen(0x1C1D20, 138, -6, -6, -12, -8);
  pen(0x1F4FB8, 142, -6, 4, -12, 6);
  pen(0xC8CBD0, 134, -14, -1, -15, 0);
  pencil(0xF1B51C, 146, 6, -7, 8, -10);   // pencils lean only slightly, so they stay clear of the sign
  pencil(0x2457C0, 150, 6, 4, 8, 7);
  pencil(0xF1B51C, 140, 12, -1, 13, -1);
  // rubber, sitting proud of its well in the bench seat
  const sb = seat.box, rub = new THREE.Mesh(new THREE.BoxGeometry(30, 10, 13), M(0xF2A7B8, 0.75));
  rub.position.set((sb.min.x + sb.max.x) / 2 - 14, sb.max.y - 1, (sb.min.z + sb.max.z) / 2);
  put(rub, seat, "Bench_Seat_prop");
  // sticky note pad leaning on the shelter panel
  const pb = panel.box, note = new THREE.Mesh(new THREE.BoxGeometry(76, 76, 5), M(0xF5E27A, 0.85));
  note.position.set((pb.min.x + pb.max.x) / 2, Math.max(sb.max.y + 40, pb.min.y + 40), pb.max.z + 3.2);
  note.rotation.x = -0.04;
  put(note, panel, "Back_Panel_prop");
  props.forEach(p => { p.home = p.o.position.clone(); m.parts.push(p); });
  m.props = props;
}
function addLampGlow(m) {
  const strip = m.parts.find(p => /Light_Strip/.test(p.name)); if (!strip) return;
  const all = new THREE.Box3(); m.parts.forEach(p => { if (!p.prop) all.union(p.box); });
  const b = strip.box, c = b.getCenter(new THREE.Vector3()), top = b.min.y, desk = all.min.y, h = top - desk;
  const g = new THREE.Group();
  const tex = (() => { const cv = document.createElement("canvas"); cv.width = 4; cv.height = 128; const x = cv.getContext("2d"), gr = x.createLinearGradient(0, 0, 0, 128);
    gr.addColorStop(0, "rgba(255,130,30,0.9)"); gr.addColorStop(1, "rgba(255,110,20,0)"); x.fillStyle = gr; x.fillRect(0, 0, 4, 128); const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t; })();
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(b.max.x - b.min.x > 20 ? 14 : 8, 60, h, 40, 1, true),
    new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
  beam.position.set(c.x, desk + h / 2, c.z); beam.scale.set(1, 1, 0.55);
  const pool = new THREE.Mesh(new THREE.CircleGeometry(70, 48), new THREE.MeshBasicMaterial({ map: SHADOW, color: 0xff7a20, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false }));
  pool.rotation.x = -Math.PI / 2; pool.position.set(c.x, desk + 0.5, c.z); pool.scale.set(1, 0.7, 1);
  const light = new THREE.PointLight(0xff8a2a, 0, 260, 0); light.position.set(c.x, top - 6, c.z);
  g.add(beam, pool, light); m.root.add(g);
  m.glow = k => {
    beam.material.opacity = 0.55 * k; pool.material.opacity = 1.6 * k; light.intensity = 2.2 * k; g.visible = k > 0.01;
    if (strip.o.material.emissive) { strip.o.material.emissive.set(0xff8a2a); strip.o.material.emissiveIntensity = 0.4 + 2.6 * k; }
  };
}
function addR42Internals(m) {
  const ctrl = m.parts.find(p => /Controller/.test(p.name)), lamp = new THREE.Box3(), strip = m.parts.find(p => /Light_Strip/.test(p.name));
  m.parts.forEach(p => { if (/Lamp_Shell/.test(p.name)) lamp.union(p.box); });
  if (!ctrl || lamp.isEmpty() || !strip) return;
  const cb = ctrl.box, cy = (cb.min.y + cb.max.y) / 2, cz = (cb.min.z + cb.max.z) / 2;
  const postX = lamp.max.x - 3.5, postZ = (lamp.min.z + lamp.max.z) / 2, armY = lamp.max.y - 3.5, endX = strip.box.min.x + 2;
  const mats = [];
  const M = c => { const mt = new THREE.MeshStandardMaterial({ color: c, roughness: 0.45, transparent: true, opacity: 0, depthWrite: false }); mats.push(mt); return mt; };
  const g = new THREE.Group(); g.renderOrder = 10;
  [[-0.9, 0xC8352B], [0.9, 0x1B1C1F]].forEach(([dz, col]) => {
    const P = (x, y, z) => new THREE.Vector3(x, y, z + dz);
    const path = new THREE.CurvePath();
    path.add(new THREE.LineCurve3(P(cb.max.x - 4, cy, cz), P(postX, cy, cz)));
    path.add(new THREE.LineCurve3(P(postX, cy, cz), P(postX, cy, postZ)));
    path.add(new THREE.LineCurve3(P(postX, cy, postZ), P(postX, armY - 12, postZ)));
    path.add(new THREE.QuadraticBezierCurve3(P(postX, armY - 12, postZ), P(postX, armY, postZ), P(postX - 12, armY, postZ)));
    path.add(new THREE.LineCurve3(P(postX - 12, armY, postZ), P(endX, armY, postZ)));
    const w = new THREE.Mesh(new THREE.TubeGeometry(path, 240, 0.6, 8, false), M(col)); w.renderOrder = 10; g.add(w);
  });
  // two cells in the controller box
  [-1, 1].forEach(k => {
    const len = Math.min(44, cb.max.x - cb.min.x - 10), r = Math.min(4, (cb.max.y - cb.min.y) / 2 - 0.5);
    const c = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 24), M(0x3E7CC9));
    c.rotation.z = Math.PI / 2; c.position.set((cb.min.x + cb.max.x) / 2, cy, cz + k * Math.min(6.5, (cb.max.z - cb.min.z) / 4)); c.renderOrder = 10; g.add(c);
  });
  m.root.add(g);
  m.internals = k => { g.visible = k > 0.02; mats.forEach(mt => { mt.opacity = k; }); };
}
function propsFade(m, k) { if (m.props) m.props.forEach(p => fadePart(p, k)); }


/* Real-time materials: swap the plain PBR materials for physical ones tuned per finish. */
const FINISH = {
  anodised:  { color: 0x2560d2, metalness: 0.0, roughness: 0.64, env: 1.0, grain: true },   // IKEA-blue satin ABS, fine moulded grain
  ikeayellow:{ color: 0xffd400, metalness: 0.0, roughness: 0.72, env: 1.25 },   // matte printed logo
  metal:     { metalness: 0.9, roughness: 0.28, env: 1.3 }, steel: { metalness: 0.9, roughness: 0.3, env: 1.3 },
  copper:    { metalness: 0.9, roughness: 0.3 },
  spgreen:   { roughness: 0.55, sheen: 0.4, sheenRoughness: 0.8, sheenColor: 0xd8f0b0 },
  sptop:     { roughness: 0.42, clearcoat: 0.25, clearcoatRoughness: 0.4 },
  spbtn:     { roughness: 0.38, clearcoat: 0.3 }, spdark: { roughness: 0.5 },
  meshblack: { roughness: 0.95, sheen: 1, sheenRoughness: 0.6, sheenColor: 0x3a3c40 },
  fabric:    { roughness: 0.95, sheen: 1, sheenRoughness: 0.6, sheenColor: 0x9aa392 },
  clear:     { roughness: 0.05 },
  toolsteel: { metalness: 0.5, roughness: 0.28, env: 1.3 }, toolcore: { metalness: 0.5, roughness: 0.34, env: 1.2 }, stripper: { roughness: 0.45 },
  cone:      { roughness: 0.6 }, surround: { roughness: 0.92 }, cell: { roughness: 0.3, clearcoat: 0.6 },
  trigger:   { roughness: 0.55, clearcoat: 0.15 }, dark: { roughness: 0.6 },
  grey:      { roughness: 0.6, clearcoat: 0.08 }, charcoal: { roughness: 0.62 }, red: { roughness: 0.4, clearcoat: 0.3 },
  pink:      { roughness: 0.42, clearcoat: 0.35, clearcoatRoughness: 0.3 }, black: { roughness: 0.85 },
  white:     { roughness: 0.55, clearcoat: 0.1 }, shell: { roughness: 0.55, clearcoat: 0.1 },
  ply:       { roughness: 0.82 }, pine: { roughness: 0.78 }, grip: { roughness: 0.98 }, tyre: { roughness: 0.92 },
  pcb:       { roughness: 0.45, clearcoat: 0.4 }, wire: { roughness: 0.5 }, wirew: { roughness: 0.5 }, sleeve: { roughness: 0.75 }, battery: { roughness: 0.35, clearcoat: 0.5 }
};
const physCache = {};
/* fine moulded-plastic grain: a tiny normal and tone variation from the surface's own position (no UVs, no geometry change), faded out where it would shimmer */
function addGrain(m) {
  m.onBeforeCompile = sh => {
    sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\nvarying vec3 vGrainP;")
      .replace("#include <begin_vertex>", "#include <begin_vertex>\nvGrainP = transformed * vec3(length(modelMatrix[0].xyz), length(modelMatrix[1].xyz), length(modelMatrix[2].xyz));");
    const N = `varying vec3 vGrainP;
      float gHash(vec3 p){ p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
      float gNoise(vec3 x){ vec3 i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);
        return mix(mix(mix(gHash(i), gHash(i + vec3(1,0,0)), f.x), mix(gHash(i + vec3(0,1,0)), gHash(i + vec3(1,1,0)), f.x), f.y),
                   mix(mix(gHash(i + vec3(0,0,1)), gHash(i + vec3(1,0,1)), f.x), mix(gHash(i + vec3(0,1,1)), gHash(i + vec3(1,1,1)), f.x), f.y), f.z); }`;
    sh.fragmentShader = sh.fragmentShader.replace("#include <common>", "#include <common>\n" + N)
      .replace("#include <color_fragment>", `#include <color_fragment>
        vec3 gP = vGrainP * 1.9; float gFade = clamp(1.6 - length(fwidth(gP)) * 0.7, 0.0, 1.0);
        float gH = 0.65 * gNoise(gP) + 0.35 * gNoise(gP * 2.3 + 5.0);
        diffuseColor.rgb *= 1.0 + (gH - 0.5) * 0.06 * gFade;`)
      .replace("#include <normal_fragment_maps>", `#include <normal_fragment_maps>
        {   // pebbled moulded texture: a real bump from the grain height, so it catches the light like the textured ABS in the render
          vec3 sX = dFdx(-vViewPosition), sY = dFdy(-vViewPosition), R1 = cross(sY, normal), R2 = cross(normal, sX);
          float det = dot(sX, R1), k = 0.065 * gFade;
          vec3 grad = sign(det) * (dFdx(gH) * k * R1 + dFdy(gH) * k * R2);
          normal = normalize(abs(det) * normal - grad);
        }`);
  };
  m.customProgramCacheKey = () => "grain";
}
function realMaterials(root) {
  root.traverse(o => {
    if (!o.isMesh || !o.material || o.material.isMeshPhysicalMaterial) return;
    const src = o.material, nm = src.name || "";
    if (!physCache[nm]) {
      const f = FINISH[nm] || {};
      const m = new THREE.MeshPhysicalMaterial({
        name: nm, color: f.color != null ? new THREE.Color(f.color) : src.color, map: src.map, side: src.side, emissive: src.emissive, emissiveIntensity: src.emissiveIntensity,
        roughness: f.roughness ?? src.roughness, metalness: f.metalness ?? src.metalness,
        clearcoat: f.clearcoat || 0, clearcoatRoughness: f.clearcoatRoughness ?? 0.3,
        sheen: f.sheen || 0, sheenRoughness: f.sheenRoughness ?? 0.8, sheenColor: new THREE.Color(f.sheenColor ?? 0xffffff),
        envMapIntensity: f.env ?? 1.0,
        transparent: src.transparent, opacity: src.opacity, depthWrite: src.depthWrite
      });
      if (src.transparent && src.map) { m.userData.keepAlpha = true; m.alphaTest = 0.02; }   // e.g. the Morrisons logo printed on the speaker grille
      if (f.grain) addGrain(m);
      physCache[nm] = m;
    }
    o.material = physCache[nm];
  });
}

/* IKEA drill: the barrel turns on the hinge between 90° (pistol) and 180° (straight). CAD is drawn at 90°. */
const _m1 = new THREE.Matrix4(), _m2 = new THREE.Matrix4(), _m3 = new THREE.Matrix4(), _up = new THREE.Vector3(0, 1, 0);
function setupHinge(m) {
  m.group.updateMatrixWorld(true);
  const P = new THREE.Vector3(0, 99.46, 0).sub(m.C); // hinge axis: along X, through the round back of the barrel
  m.parts.forEach(p => {
    if (!/^(Front[ _]Left|Layer[ _]01|LOGO-IKEA|motor|INT-drive)__|^INT-(wires|sleeve)__b\d+$|^INT-screws__barrel$/.test(p.name)) return;
    p.hinge = { pl: p.o.parent.worldToLocal(P.clone()), M0: p.o.matrix.clone() };
  });
  // rubber USB plug: pulls straight out of the port, then hangs; a thin strap always spans anchor -> plug foot
  const A = new THREE.Vector3(0, 73.2, 22.2).sub(m.C), B = new THREE.Vector3(0, 75.8, 22.0).sub(m.C);
  m.parts.forEach(p => {
    if (/^PLUG-USB__/.test(p.name)) p.flap = { kind: "plug", pl: p.o.parent.worldToLocal(A.clone()), M0: p.o.matrix.clone() };
    if (/^PLUG-TETHER__/.test(p.name)) { p.o.visible = false; p.hidden = true; }   // no cord: the plug simply pulls out of its slot
  });
}
function applyDrill(m, a, e, fl = 0) {
  m.parts.forEach(p => {
    if (p.hidden) return;
    if (p.sleeve) p.o.visible = e < 0.03;
    if (p.flap) {
      // plug: slides straight out of its slot along the port axis and holds there; scrolling back pushes it home
      const d = 12.0 * smooth(clamp(fl / 0.6, 0, 1));
      _m1.makeTranslation(0, 0, d).multiply(p.flap.M0); _m1.decompose(p.o.position, p.o.quaternion, p.o.scale);
      p.o.position.addScaledVector(p.ex, e);
      return;
    }
    if (p.hinge && a > 1e-4) {
      const pl = p.hinge.pl;
      _m1.makeTranslation(pl.x, pl.y, pl.z).multiply(_m2.makeRotationX(a)).multiply(_m3.makeTranslation(-pl.x, -pl.y, -pl.z)).multiply(p.hinge.M0);
      _m1.decompose(p.o.position, p.o.quaternion, p.o.scale);
      p.o.position.addScaledVector(p.ex, e);
    } else {
      if (p.hinge) { p.hinge.M0.decompose(p.o.position, p.o.quaternion, p.o.scale); }
      else p.o.position.copy(p.home);
      p.o.position.addScaledVector(p.ex, e);
    }
  });
}

/* Morrisons speaker: shells part front and back, then every part. */
function speakerVectors(m) {
  m.parts.forEach(p => {
    const n = p.name, d = p.c, s1 = new THREE.Vector3(), s2 = new THREE.Vector3();
    if (/SHELL-FRONT|GRILLE__0|WORDMARK|GRILLE_BACKER|PORT-DOOR/.test(n)) s1.z = 62;
    else if (/SHELL-REAR|GRILLE__(8|9)|LOGO-/.test(n)) s1.z = -62;
    s2.set(d.x * 0.35, d.y * 0.5, d.z * 0.5);
    if (/BUTTON|INT-button|INT-switch|MARKS/.test(n)) s2.y += 34;
    if (/INT-cell/.test(n)) s2.x += Math.sign(d.x) * 30;
    if (/INT-pcb|INT-usbc/.test(n)) s2.y -= 24;
    if (/INT-driver/.test(n)) s2.z += 18;
    if (/INT-pr/.test(n)) s2.z -= 18;
    p.st = [s1, s2];
  });
}

/* speaker: the new lid, trims, base band, seams and grille travel with the shell they belong to, so nothing doubles up when it comes apart */
function speakerFollow(m) {
  const host = n => m.parts.find(p => p.name === n);
  const map = [[/^SHELL-FRONT-TOP__lid(line)?$/, "SHELL-FRONT-TOP__11"], [/^SHELL-REAR-TOP__lid(line)?$/, "SHELL-REAR-TOP__13"],
    [/^SHELL-FRONT-TOP__(rail|frame)$|^SHELL-FRONT__seam$|^GRILLE__0$|^WORDMARK__1$|^GRILLE_BACKER__99$/, "SHELL-FRONT__10"],
    [/^SHELL-REAR-TOP__rail$|^SHELL-REAR__seam$|^SHELL-REAR__16$/, "SHELL-REAR__12"]];
  m.parts.forEach(p => map.forEach(([re, h]) => {
    if (!re.test(p.name)) return; const q = host(h); if (!q) return;
    if (q.ex) p.ex = q.ex.clone();
    if (q.st) p.st = q.st.map(v => v.clone());
  }));
}

/* ------------------------------------------------------------ views */
const V3 = new THREE.Vector3();
class View {
  constructor(el) {
    this.el = el;
    this.keys = (el.dataset.family || el.dataset.model).split(",");
    this.family = !!el.dataset.family;
    this.story = el.dataset.story || null;
    this.pageExplode = el.dataset.explode === "page";
    this.yaw = parseFloat(el.dataset.yaw || -0.6); this.pitch = parseFloat(el.dataset.pitch || 0.24);
    this.fit = parseFloat(el.dataset.fit || 1);
    this.userYaw = 0; this.userPitch = 0; this.vy = 0; this.drag = null;
    this.target = new THREE.Vector3(); this.zoom = 1;
    this.scene = new THREE.Scene(); this.scene.environment = envTex;
    const key = new THREE.DirectionalLight(0xffffff, 1.3); key.position.set(-1, 2, 1.4); this.scene.add(key);
    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x8a8680, 0.45));
    this.camera = new THREE.PerspectiveCamera(26, 1, 1, 5000);
    this.bind();
    lazy.observe(el);
  }
  load() {
    if (this.loading) return; this.loading = true;
    Promise.all(this.keys.map(getModel)).then(srcs => this.setup(srcs)).catch(e => { console.error(e); this.loading = false; this.el.classList.add('failed'); });
  }
  setup(srcs) {
    requestAnimationFrame(() => requestAnimationFrame(() => this.el.classList.add("ready")));
    const ghost = this.story === "r42" || this.story === "speaker";
    this.models = srcs.map((s, i) => {
      const m = prepare(s, ghost); m.key = this.keys[i];
      if (m.key === "r42" && this.story === "r42") r42Vectors(m);
      else if (m.key === "speaker" && this.story === "speaker") speakerVectors(m);
      else explodeVectors(m.key, m);
      if (m.key === "drill") { stickLogo(m); setupHinge(m); }
      if (m.key === "speaker") speakerFollow(m);
      if (m.key === "r42") addR42Props(m);
      if (m.key === "r42" && this.story === "r42") { addLampGlow(m); addR42Internals(m); }
      return m;
    });
    const shadow = (m, w, d) => {
      const sh = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: SHADOW, transparent: true, depthWrite: false }));
      sh.rotation.x = -Math.PI / 2; sh.position.y = -m.size.y / 2 - 0.2; sh.scale.set(w, d, 1); sh.renderOrder = -1; return sh;
    };
    if (this.family) {
      // every product scaled to the same presence, set out in a row
      const R = 100;
      this.models.forEach(m => {
        const s = R / m.radius, holder = new THREE.Group(), spin = new THREE.Group();
        spin.add(m.group); spin.add(shadow(m, m.size.x * 1.5 + m.size.z * 0.3, m.size.z * 1.6 + m.size.x * 0.3));
        holder.add(spin); holder.scale.setScalar(s);
        m.holder = holder; m.spin = spin; m.lift = (m.size.y / 2) * s; this.scene.add(holder);
      });
      const pref = { r42: -0.62, henry: 2.2, crumbbuddy: 0.9, drill: 0.9, speaker: -0.55, scooter: -0.7 };
      this.models.forEach(m => { m.spin.rotation.y = -(pref[m.key] || 0); });
      this.radius = R;
    } else {
      const m = this.models[0];
      this.scene.add(m.group);
      m.group.add(shadow(m, m.size.x * 1.5 + m.size.z * 0.3, m.size.z * 1.8 + m.size.x * 0.3));
      this.radius = m.radius;
      if (this.story === "r42") {
        const C0 = new THREE.Vector3();
        this.keysR42 = [
          { tgt: C0, z: 0.9, yaw: -0.6, p: 0.22, w: [0, 0, 0], f: null },
          { tgt: C0, z: 1.2, yaw: -0.55, p: 0.3, w: [0, 1, 0], f: null },
          { tgt: centreOf(m, /Pen_Holder/).add(new THREE.Vector3(0, 38, 0)), z: 0.82, yaw: -0.95, p: 0.28, w: [0, 0, 0], f: /Pen_Holder/ },
          { tgt: centreOf(m, /Bench_Seat|Bench_Tray/), z: 0.66, yaw: -0.08, p: 0.22, w: [1, 0, 0], f: /Bench/ },
          { tgt: centreOf(m, /Lamp_Shell|Light_Strip|Diffuser/).add(new THREE.Vector3(0, -35, 0)), z: 0.95, yaw: -0.35, p: 0.14, w: [0, 0, 0], f: /Light_Strip|Diffuser|Controller/ },
          { tgt: C0, z: 1.35, yaw: -0.62, p: 0.26, w: [1, 1, 1], f: null }
        ];
      }
      if (this.story === "drill") {
        const C0 = new THREE.Vector3(), H = Math.PI / 2;
        this.K = [
          { tgt: C0, z: 1.0, yaw: 0.95, p: 0.12, h: 0, e: 0 },
          { tgt: new THREE.Vector3(0, 45, 0), z: 1.3, yaw: 1.45, p: 0.08, h: H, e: 0 },
          { tgt: C0, z: 1.0, yaw: 1.3, p: 0.1, h: 0, e: 0 },
          { tgt: centreOf(m, /INT-magnet/).add(new THREE.Vector3(0, 40, 0)), z: 0.85, yaw: 0.6, p: -0.22, h: 0, e: 0 },
          { tgt: centreOf(m, /INT-charge/), z: 0.78, yaw: 0.45, p: 0.12, h: 0, e: 0, fl: 1 },
          { tgt: centreOf(m, /LOGO-IKEA/), z: 0.66, yaw: 1.45, p: 0.18, h: 0, e: 0 },
          { tgt: C0, z: 1.3, yaw: 0.85, p: 0.25, h: 0, e: 1 }
        ];
        this.fitK = 0.9;
      }
      if (this.story === "speaker") {
        const C0 = new THREE.Vector3(), rear = centreOf(m, /SHELL-REAR__/).add(new THREE.Vector3(0, 0, -62));
        this.K = [
          { tgt: C0, z: 0.95, yaw: -0.55, p: 0.22, e: 0, f: null },
          { tgt: C0, z: 0.85, yaw: -0.2, p: 0.85, e: 0, f: null },
          { tgt: C0, z: 1.3, yaw: -0.85, p: 0.32, e: 1, f: /INT-/ },
          { tgt: rear, z: 1.05, yaw: 0.2, p: 0.6, e: 1, f: /SHELL-REAR__/ },
          { tgt: C0, z: 1.45, yaw: -0.6, p: 0.3, e: 2, f: null }
        ];
        this.fitK = 0.9;
      }
    }
    this.ready = true;
  }
  bind() {
    const el = this.el;
    el.addEventListener("pointerdown", e => { this.drag = { x: e.clientX, y: e.clientY }; this.moved = false; el.setPointerCapture(e.pointerId); });
    el.addEventListener("pointermove", e => {
      if (!this.drag) return;
      const dx = e.clientX - this.drag.x, dy = e.clientY - this.drag.y;
      if (Math.abs(dx) + Math.abs(dy) > 4) this.moved = true;
      this.userYaw += dx * 0.009; this.userPitch = clamp(this.userPitch + dy * 0.004, -0.3, 0.6);
      this.vy = dx * 0.009; this.drag.x = e.clientX; this.drag.y = e.clientY;
    });
    const end = () => { this.drag = null; };
    el.addEventListener("pointerup", end); el.addEventListener("pointercancel", end);
    const a = el.closest("a");
    if (a) a.addEventListener("click", e => { if (this.moved) e.preventDefault(); this.moved = false; }, true);
  }
  visible(H) {
    const r = this.el.getBoundingClientRect(); this.rect = r;
    return this.ready && r.bottom > 0 && r.top < H && r.width > 2 && r.height > 2;
  }
  render(dt, W, H) {
    const r = this.rect;
    if (!this.drag) { this.userYaw += this.vy; this.vy *= 0.92; }
    const spinOn = !this.story;
    let yaw = this.yaw + this.userYaw, pitch = this.pitch + this.userPitch, zoom = 1, fitR = this.radius;
    this.target.set(0, 0, 0);

    if (this.family) {
      const narrow = r.width / r.height < 1.45, R = this.radius, n = this.models.length;
      this.models.forEach((m, i) => {
        if (spinOn && !this.drag) m.spin.rotation.y += dt * (reduce ? 0.1 : 0.22) * (i % 2 ? -1 : 1);
        if (narrow) { const cx = i % 2, cy = Math.floor(i / 2); m.holder.position.set((cx - 0.5) * R * 2.1, (0.5 - cy) * R * 2.0, 0); }
        else m.holder.position.set((i - (n - 1) / 2) * R * 2.05, 0, 0);
      });
      this.fitW = narrow ? R * 2.2 : R * (n * 1.02 + 0.2); this.fitH = narrow ? R * 2.15 : R * 1.25;
      if (spinOn && !this.drag) this.userYaw *= 0.97;
      yaw = this.userYaw * 0.4; pitch = 0.16 + this.userPitch * 0.5;
    } else if (this.story === "r42") {
      const m = this.models[0], K = this.keysR42, s = clamp(this.s || 0, 0, K.length - 1);
      const i = Math.min(K.length - 2, Math.floor(s)), f = smooth((s - i - 0.2) / 0.6), a = K[i], b = K[i + 1];
      this.target.lerpVectors(a.tgt, b.tgt, f);
      zoom = lerp(a.z, b.z, f); yaw = lerp(a.yaw, b.yaw, f) + this.userYaw; pitch = lerp(a.p, b.p, f) + this.userPitch;
      const w = a.w.map((x, k) => lerp(x, b.w[k], f)), e = w[1] + w[2];
      applyR42(m, w);
      if (m.glow) m.glow(clamp(1 - Math.abs(s - 4) * 1.6, 0, 1));
      if (m.internals) m.internals(lerp(a.f ? 1 : 0, b.f ? 1 : 0, f) * (1 - w[2]));
      const keep = 1 - smooth((w[2] - 0.1) / 0.6);
      // ghost everything except the part in focus
      m.parts.forEach(p => {
        const oa = a.f ? (a.f.test(p.name) ? 1 : 0.1) : 1, ob = b.f ? (b.f.test(p.name) ? 1 : 0.1) : 1;
        let op = lerp(oa, ob, f); if (p.prop) op *= keep;
        if (p.prop) fadePart(p, op); else setOpacity(p.o.material, op);
      });
      fitR = this.radius * 0.84;
    } else if (this.K) {
      const m = this.models[0], K = this.K, s = clamp(this.s || 0, 0, K.length - 1);
      const i = Math.min(K.length - 2, Math.floor(s)), f = smooth((s - i - 0.2) / 0.6), a = K[i], b = K[i + 1];
      this.target.lerpVectors(a.tgt, b.tgt, f);
      zoom = lerp(a.z, b.z, f); yaw = lerp(a.yaw, b.yaw, f) + this.userYaw; pitch = lerp(a.p, b.p, f) + this.userPitch;
      const e = lerp(a.e, b.e, f);
      if (m.key === "drill") applyDrill(m, lerp(a.h, b.h, f), smooth(e), lerp(a.fl || 0, b.fl || 0, f));
      else applyR42(m, e);
      if (a.f !== undefined) m.parts.forEach(p => {
        const oa = a.f ? (a.f.test(p.name) ? 1 : 0.07) : 1, ob = b.f ? (b.f.test(p.name) ? 1 : 0.07) : 1;
        setOpacity(p.o.material, lerp(oa, ob, f));
      });
      fitR = this.radius * this.fitK;
    } else if (this.story === "henry") {
      const m = this.models[0], sm = this.sMax || 3, s = clamp(this.s || 0, 0, sm), k = s / sm;
      applyExplode(m, smooth(k));
      yaw = 2.2 - k * 0.3 + this.userYaw; pitch = 0.26 + k * 0.12 + this.userPitch;
      zoom = 1 + k * 0.95; fitR = this.radius * 1.02;
    } else if (this.story === "scooter") {
      const m = this.models[0], s = clamp(this.s || 0, 0, 2);
      applyExplode(m, smooth((s - 0.6) / 1.4) * 0.9);
      yaw = -0.75 + s * 0.25 + this.userYaw; pitch = 0.22 + this.userPitch;
      zoom = 1 + smooth((s - 0.6) / 1.4) * 0.35; fitR = this.radius * 0.95;
    } else {
      if (spinOn && !this.drag) this.yaw += dt * (reduce ? 0.1 : 0.25);
      if (this.keys[0] === "r42tool") {
        const m = this.models[0]; this.toolT = (this.toolT || 0) + dt / 7; const t = this.toolT % 1;
        const open = smooth((t - 0.12) / 0.18) * (1 - smooth((t - 0.82) / 0.14));
        const eject = smooth((t - 0.34) / 0.14) * (1 - smooth((t - 0.72) / 0.1));
        const lift = smooth((t - 0.48) / 0.14) * (1 - smooth((t - 0.7) / 0.1));
        m.parts.forEach(p => {
          p.o.position.copy(p.home);
          if (/cavity|sprue/.test(p.name)) p.o.position.y += 150 * open;
          if (/stripper/.test(p.name)) p.o.position.y += 26 * eject;
          if (/moulding/.test(p.name)) p.o.position.y += 26 * eject + 70 * lift;
        });
        zoom = 1.05;
      }
      if (this.pageExplode) {
        this.ex = (this.ex || 0) + ((this.exOn ? 1 : 0) - (this.ex || 0)) * Math.min(1, dt * (reduce ? 60 : 3.2));
        const t = smooth(this.ex); applyExplode(this.models[0], t); zoom = 1 + t * 0.7;
        propsFade(this.models[0], 1 - smooth(this.ex * 2.5));
      }
    }

    const cam = this.camera, aspect = r.width / r.height; cam.aspect = aspect;
    const vf = THREE.MathUtils.degToRad(cam.fov), hf = 2 * Math.atan(Math.tan(vf / 2) * aspect);
    let d = (fitR * 1.12 / Math.sin(Math.min(vf, hf) / 2)) / this.fit * zoom;
    if (this.story && aspect < 0.8) { d *= this.story === "speaker" ? 1.0 : 1.28; if (zoom < 1) d *= (1 - (1 - zoom) * 0.5) / zoom; } // phones: pull back, and soften the close-ups so the product isn't cropped // phones: pull back so the whole product stays in frame under the words
    if (this.family) d = Math.max(this.fitW / Math.tan(hf / 2), this.fitH / Math.tan(vf / 2));
    V3.set(Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch)).multiplyScalar(d);
    cam.position.copy(this.target).add(V3); cam.lookAt(this.target);
    cam.near = d / 30; cam.far = d * 5;
    // stories: push the model away from the words
    if (this.story) {
      if (aspect > 1.15) cam.setViewOffset(r.width, r.height, -r.width * 0.14, 0, r.width, r.height);
      else cam.setViewOffset(r.width, r.height, 0, -r.height * 0.12, r.width, r.height);
    } else cam.clearViewOffset();
    cam.updateProjectionMatrix();
    if (COPY) {
      // phones: draw in the corner of the shared GL canvas, then copy into this view's own canvas, which sits in the page and scrolls natively
      const w = Math.max(1, Math.round(r.width)), h = Math.max(1, Math.round(r.height)), y0 = H - h;
      renderer.setViewport(0, y0, w, h); renderer.setScissor(0, y0, w, h); renderer.clear(); renderer.render(this.scene, cam);
      if (!this.vc) { this.vc = document.createElement("canvas"); this.vc.className = "vc"; this.el.appendChild(this.vc); this.ctx = this.vc.getContext("2d"); }
      const pr = renderer.getPixelRatio(), sw = Math.round(w * pr), sh = Math.round(h * pr);
      if (this.vc.width !== sw || this.vc.height !== sh) { this.vc.width = sw; this.vc.height = sh; }
      this.ctx.clearRect(0, 0, sw, sh); this.ctx.drawImage(canvas, 0, 0, sw, sh, 0, 0, sw, sh);
      return;
    }
    const x = r.left, y = H - r.bottom;
    renderer.setViewport(x, y, r.width, r.height); renderer.setScissor(x, y, r.width, r.height);
    renderer.render(this.scene, cam);
  }
}

/* load models only when a view gets near the screen */
const lazy = new IntersectionObserver(es => es.forEach(e => {
  if (e.isIntersecting) { const v = views.find(v => v.el === e.target); if (v) v.load(); lazy.unobserve(e.target); }
}), { rootMargin: innerWidth < 760 ? "200% 0px" : "120% 0px" });
const views = [];
document.querySelectorAll(".view[data-model], .view[data-family]").forEach(el => views.push(new View(el)));
// once the page has settled, download the remaining models one by one so no 3D box is still loading when you reach it
const warmAll = () => setTimeout(() => {
  const keys = [...new Set(views.flatMap(v => v.keys || []))];
  keys.reduce((p, k) => p.then(() => getModel(k).catch(() => {})), Promise.resolve());
}, 2500);
if (innerWidth >= 760) { if (document.readyState === "complete") warmAll(); else addEventListener("load", warmAll); }   // phones: models load as their section approaches instead

/* ------------------------------------------------------------ scroll state */
let pageT = 0;
const projects = document.getElementById("projects"), r42 = document.getElementById("route42");
function stories() {
  document.querySelectorAll(".story").forEach(st => {
    const v = views.find(v => st.contains(v.el)), q = st.querySelector(".seq"); if (!v && !q) return;
    const steps = [...st.querySelectorAll(".step")], ticks = [...st.querySelectorAll(".ticks b")], n = steps.length;
    const r = st.getBoundingClientRect(), total = r.height - SVH;
    const p = clamp(-r.top / Math.max(total, 1), 0, 1);
    const s = clamp(p * (n - 1 + 0.6) - 0.3, 0, n - 1);
    if (v) { v.s = s; v.sMax = n - 1; }
    if (q) seqFrame(q, s, n);
    const i = Math.round(s);
    ticks.forEach((b, k) => { b.style.transform = "scaleX(" + clamp(s - k + 1, 0, 1) + ")"; });
    if (st._i !== i) { steps.forEach((el, k) => el.classList.toggle("on", k === i)); st._i = i; st.dataset.s = i; }
  });
}

/* rendered frame sequences: the frames already carry the easing, holds sit between them */
const SEQ = window.SEQ || {};
function seqSrc(q, k) { const p = q.dataset.src + String(k).padStart(3, "0") + ".webp"; return SEQ[p] || p; }
function seqFrame(q, s, n) {
  const seg = +q.dataset.seg, i = Math.min(n - 2, Math.floor(s)), t = clamp((s - i - 0.2) / 0.6, 0, 1);
  const k = Math.round((i + t) * seg);
  if (q._k === k) return; q._k = k;
  const im = q.querySelector("img"), src = seqSrc(q, k);
  if (q._c && q._c[k] && q._c[k].complete) im.src = q._c[k].src; else im.src = src;
}
const seqWarm = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return; const q = e.target; seqWarm.unobserve(q);
  q._c = []; for (let k = 0; k < +q.dataset.n; k++) { const im = new Image(); im.decoding = "async"; im.src = seqSrc(q, k); q._c[k] = im; }
}), { rootMargin: "200% 0px" });
document.querySelectorAll(".seq").forEach(q => seqWarm.observe(q));

/* explode buttons on the project cards */
document.querySelectorAll(".xbtn").forEach(b => {
  const host = b.closest(".item, .hh-model"); const v = host && views.find(v => host.contains(v.el)); if (!v) return;
  b.addEventListener("click", () => {
    v.exOn = b._demo ? true : !v.exOn; b._demo = false; b.setAttribute("aria-pressed", v.exOn); b.textContent = v.exOn ? "Assemble" : "Explode"; b.setAttribute("aria-label", (v.exOn ? "Assemble " : "Explode ") + (b.dataset.name || "the model"));
    v.load();
  });
});

/* ------------------------------------------------------------ rendered turntables on the opening page */
document.querySelectorAll(".turn.spin").forEach((el, k) => {
  const n = +el.dataset.n, base = el.dataset.src, A = el.querySelector("img.a"), B = el.querySelector("img.b");
  const TT = window.TT || {}, src = i => { const p = base + String(((i % n) + n) % n).padStart(3, "0") + ".webp"; return TT[p] || p; };
  for (let i = 0; i < n; i++) { const im = new Image(); im.src = src(i); }   // warm the cache
  let f = 0, v = (k % 2 ? -1 : 1) * n / 11, drag = null, last = performance.now(), shown = -1;
  el.addEventListener("pointerdown", e => { drag = e.clientX; el.setPointerCapture(e.pointerId); });
  el.addEventListener("pointermove", e => { if (drag === null) return; const dx = e.clientX - drag; drag = e.clientX; f -= dx * n / 360; v = -dx * n / 360 * 30; });
  const end = () => { drag = null; v = Math.sign(v || 1) * n / 11; };
  el.addEventListener("pointerup", end); el.addEventListener("pointercancel", end);
  (function tick(now) {
    requestAnimationFrame(tick);
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    const r = el.getBoundingClientRect(); if (r.bottom < 0 || r.top > innerHeight) return;
    if (drag === null) f += dt * v * (reduce ? 0.4 : 1);
    const i = Math.floor(f), t = f - i;
    if (i !== shown) { A.src = src(i); B.src = src(i + 1); shown = i; }
    B.style.opacity = t.toFixed(3);
  })(last);
});

/* ------------------------------------------------------------ nudges */
const teaser = new IntersectionObserver(es => es.forEach(e => {
  if (!e.isIntersecting) return; teaser.unobserve(e.target);
  const b = e.target.querySelector(".xbtn"), v = views.find(v => e.target.contains(v.el)); if (!b || !v) return;
  const k = [...document.querySelectorAll(".lineup .item")].indexOf(e.target);
  setTimeout(() => { if (b.dataset.used) return; v.load(); v.exOn = true; b._demo = true; setTimeout(() => { b._demo = false; if (!b.dataset.used) v.exOn = false; }, 1700); }, 700 + k * 450);
}), { threshold: 0.6 });
document.querySelectorAll(".lineup .item").forEach(it => teaser.observe(it));
document.querySelectorAll(".xbtn").forEach(b => b.addEventListener("click", () => { b.dataset.used = 1; b.classList.remove("pulse"); }));
document.querySelectorAll(".xbtn").forEach(b => b.classList.add("pulse"));
// card links: mark the one you picked, and flash the heading you land on
document.querySelectorAll(".item .links a").forEach(a => a.addEventListener("click", () => {
  a.closest(".links").querySelectorAll("a").forEach(x => x.classList.toggle("on", x === a));
  const t = document.querySelector(a.getAttribute("href")); if (!t) return;
  t.classList.remove("arrive"); void t.offsetWidth; t.classList.add("arrive"); setTimeout(() => t.classList.remove("arrive"), 2200);
}));

/* ------------------------------------------------------------ loop */
let W = 0, H = 0;
/* phone toolbar showing/hiding changes only the height: keep the canvas at the tallest height seen for this width instead of rebuilding it, and measure scroll stories against the small viewport (100svh), which the toolbar never changes */
const probe = document.createElement("div"); probe.style.cssText = "position:fixed;top:0;left:0;width:0;height:100vh;height:100svh;visibility:hidden;pointer-events:none"; document.body.appendChild(probe);
let SVH = probe.offsetHeight || innerHeight;
function size() {
  const w = document.documentElement.clientWidth, h = innerHeight;
  if (w === W && h <= H && H - h < 200) return;
  if (w !== W) { H = h; SVH = probe.offsetHeight || h; } else H = Math.max(H, h);
  W = w; renderer.setSize(W, H, false); canvas.style.width = W + "px"; canvas.style.height = H + "px";
}
size(); addEventListener("resize", size);
const clock = new THREE.Clock();
let wasEmpty = false;
function frame() {
  requestAnimationFrame(frame);
  if (document.hidden) return;
  const dt = Math.min(clock.getDelta(), 0.05);
  stories();
  const vis = views.filter(v => v.visible(H));
  if (!vis.length) { if (!wasEmpty) { renderer.setScissor(0, 0, W, H); renderer.clear(); wasEmpty = true; } return; }
  wasEmpty = false;
  renderer.setScissor(0, 0, W, H); renderer.clear();
  vis.forEach(v => v.render(dt, W, H));
}
frame();
