/* Page UI that must work even if the 3D code is slow or fails: reveal-on-scroll, nav highlight, process-card lightbox. */
(function () {
document.documentElement.classList.add("js");
/* ------------------------------------------------------------ reveal + nav */
const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { rootMargin: "0px 0px -6% 0px" });
document.querySelectorAll(".rv").forEach(el => { if (el.getBoundingClientRect().top < innerHeight) el.classList.add("in"); else io.observe(el); });
const links = [...document.querySelectorAll(".bar nav a")];
const secs = links.map(a => { const h = a.getAttribute("href"); return h && h[0] === "#" ? document.querySelector(h) : null; });
function navOn() {
  let cur = -1;
  secs.forEach((s, i) => { if (s && s.getBoundingClientRect().top < innerHeight * 0.35) cur = i; });
  links.forEach((a, i) => a.classList.toggle("on", i === cur));
  if (cur !== navOn.last) { navOn.last = cur; const a = links[cur], nav = a && a.parentNode; if (a && nav.scrollWidth > nav.clientWidth) nav.scrollTo({ left: a.getBoundingClientRect().left - nav.getBoundingClientRect().left + nav.scrollLeft - (nav.clientWidth - a.offsetWidth) / 2, behavior: "smooth" }); }
}
addEventListener("scroll", navOn, { passive: true }); navOn();

/* ------------------------------------------------------------ journey lightbox */
const lb = document.getElementById("lb");
if (lb) {
  const img = lb.querySelector("img"), t = lb.querySelector("h4"), d = lb.querySelector("p"), k = lb.querySelector(".k"),
        cap = lb.querySelector(".cap"), prev = lb.querySelector(".prev"), next = lb.querySelector(".next"), cnt = lb.querySelector(".cnt");
  let set = [], at = 0;
  const show = () => { const [src, c] = set[at]; img.src = src; img.alt = c; cap.textContent = set.length > 1 ? c : ""; cnt.textContent = (at + 1) + " / " + set.length; };
  document.querySelectorAll(".jm").forEach(b => b.addEventListener("click", () => {
    const im = b.querySelector("img");
    set = b.dataset.gallery ? b.dataset.gallery.split(";").map(x => x.split("|")) : [[im ? im.currentSrc || im.src : "", im ? im.alt : ""]];
    at = 0; show();
    const many = set.length > 1; prev.hidden = next.hidden = cnt.hidden = !many; img.hidden = !im;
    t.textContent = b.querySelector("b").textContent; k.textContent = b.querySelector(".k").textContent;
    d.textContent = b.dataset.d || "";
    lb.showModal();
  }));
  prev.addEventListener("click", e => { e.stopPropagation(); at = (at + set.length - 1) % set.length; show(); });
  next.addEventListener("click", e => { e.stopPropagation(); at = (at + 1) % set.length; show(); });
  lb.addEventListener("keydown", e => { if (set.length > 1 && e.key === "ArrowRight") next.click(); if (set.length > 1 && e.key === "ArrowLeft") prev.click(); });
  lb.addEventListener("click", e => { if (e.target === lb || e.target.closest(".x")) lb.close(); });
}



/* images: if one fails on a patchy connection, try again (twice) instead of leaving a blank box */
document.addEventListener("error", e => {
  const im = e.target; if (!(im instanceof HTMLImageElement) || im.src.startsWith("data:")) return;
  const n = +(im.dataset.retry || 0); if (n >= 2) return; im.dataset.retry = n + 1;
  setTimeout(() => { const u = new URL(im.src, location.href); u.searchParams.set("r", n + 1); im.src = u.href; }, 800 * (n + 1));
}, true);
})();
